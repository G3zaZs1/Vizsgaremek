<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/download.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
</head>
<body>
    <div class="wrapper">
        <?php include 'header/header_download.php'; ?> 

        <div class="content">           
            <h3>
                Szeretnél offline játszani?
            </h3>
            <p>A letöltés gombra kattinva letöltheted a játékot tömörített formában, amelyet kicsimagolás után índíthatod a játékot.</p>
            <a href="../downloads/download.zip" download>Letöltés</a>
        </div>

        <?php include 'footer/footer.php'; ?> 

    </div>
</body>
</html>