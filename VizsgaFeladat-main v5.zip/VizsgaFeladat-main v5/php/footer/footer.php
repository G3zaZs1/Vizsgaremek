<footer>
        <small>@ copyrights idk</small>
</footer>