<header>
            <div id="mainpage" class="headline">
                <ul>
                    <li><h3>download</h3></li>
                    <li><a href="">back to main</a></li>
                    <li><a href="">no</a></li>
                    <li><a href="">maybe</a></li>
                </ul>
                <ul id="log">
                    <li><a href="../admin/login.php">Logout</a></li>
                </ul>
            </div>

</header>