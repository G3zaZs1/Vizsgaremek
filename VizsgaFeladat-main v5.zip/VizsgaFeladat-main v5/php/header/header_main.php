<header>
        <div id="mainpage" class="headline">
            <ul>
                <li><h3>Main</h3></li>
                <li><a href="../php/player.php">Player</a></li>
                <li><a href="../php/download.php">Download</a></li>
                <li><a href="">maybe</a></li>
            </ul>
            <ul id="log">
                <li><a href="../admin/login.php">Logout</a></li>
            </ul>
        </div>
    </header>